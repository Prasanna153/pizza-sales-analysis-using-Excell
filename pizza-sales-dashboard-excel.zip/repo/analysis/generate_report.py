"""
Pizza Sales Analysis — regenerates all KPIs and the dashboard preview image
from the raw data in data/pizza_sales_dashboard.xlsx.

Usage:  python analysis/generate_report.py
Output: analysis/kpi_summary.csv, analysis/breakdowns.csv, assets/dashboard_preview.png
"""

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "pizza_sales_dashboard.xlsx"
ASSETS = ROOT / "assets"
ASSETS.mkdir(exist_ok=True)

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def load() -> pd.DataFrame:
    df = pd.read_excel(DATA, sheet_name="Table1")
    return df.loc[:, ~df.columns.str.startswith("Unnamed")]


def kpis(df: pd.DataFrame) -> pd.DataFrame:
    revenue = df["total_price"].sum()
    orders = df["order_id"].nunique()
    pizzas = int(df["quantity"].sum())
    rows = [
        ("Total revenue", round(revenue, 2)),
        ("Total orders", orders),
        ("Total pizzas sold", pizzas),
        ("Average order value", round(revenue / orders, 2)),
        ("Average pizzas per order", round(pizzas / orders, 2)),
        ("Average orders per day", round(orders / df["order_date"].nunique(), 2)),
    ]
    return pd.DataFrame(rows, columns=["metric", "value"])


def breakdowns(df: pd.DataFrame) -> pd.DataFrame:
    frames = []
    specs = {
        "category": "pizza_category",
        "size": "pizza_size",
        "pizza": "pizza_name",
        "day_of_week": "Day Name",
        "month": "Month",
        "hour": "Hour",
    }
    for label, col in specs.items():
        g = df.groupby(col).agg(
            revenue=("total_price", "sum"),
            orders=("order_id", "nunique"),
            quantity=("quantity", "sum"),
        ).reset_index()
        g.columns = ["value", "revenue", "orders", "quantity"]
        g.insert(0, "dimension", label)
        g["revenue"] = g["revenue"].round(2)
        frames.append(g)
    return pd.concat(frames, ignore_index=True)


def dashboard(df: pd.DataFrame, k: pd.DataFrame) -> Path:
    plt.rcParams.update({
        "figure.facecolor": "#14171c", "axes.facecolor": "#1b1f26",
        "axes.edgecolor": "#2c323c", "text.color": "#e8eaed",
        "axes.labelcolor": "#a8b0bd", "xtick.color": "#a8b0bd",
        "ytick.color": "#a8b0bd", "font.family": "DejaVu Sans",
        "axes.grid": True, "axes.axisbelow": True, "grid.color": "#262b33", "grid.linewidth": 0.7,
    })
    accent, accent2 = "#ff7a33", "#4cc38a"

    fig = plt.figure(figsize=(16, 9.5))
    gs = fig.add_gridspec(3, 3, hspace=0.55, wspace=0.28,
                          top=0.75, bottom=0.07, left=0.06, right=0.97)

    fig.text(0.06, 0.945, "Pizza Sales Dashboard", fontsize=26, fontweight="bold")
    fig.text(0.06, 0.912, "Plato's Pizza  ·  full year 2015  ·  48,620 order lines",
             fontsize=12, color="#8b93a1")

    cards = [
        ("TOTAL REVENUE", f"${k.loc[0, 'value']:,.0f}"),
        ("TOTAL ORDERS", f"{int(k.loc[1, 'value']):,}"),
        ("PIZZAS SOLD", f"{int(k.loc[2, 'value']):,}"),
        ("AVG ORDER VALUE", f"${k.loc[3, 'value']:,.2f}"),
    ]
    for i, (label, value) in enumerate(cards):
        x = 0.06 + i * 0.2325
        fig.patches.append(plt.Rectangle((x, 0.825), 0.215, 0.068, transform=fig.transFigure,
                                         facecolor="#1b1f26", edgecolor="#2c323c", zorder=0))
        fig.text(x + 0.012, 0.868, label, fontsize=9, color="#8b93a1")
        fig.text(x + 0.012, 0.838, value, fontsize=19, fontweight="bold", color=accent)

    # Monthly revenue
    ax = fig.add_subplot(gs[0, :2])
    m = df.groupby("Month")["total_price"].sum().reindex(range(1, 13))
    ax.plot(MONTHS, m.values, color=accent, marker="o", linewidth=2.2, markersize=5)
    ax.fill_between(MONTHS, m.values, color=accent, alpha=0.12)
    ax.set_title("Revenue by month", loc="left", fontsize=12, fontweight="bold", pad=10)
    ax.set_ylim(0, m.max() * 1.25)
    ax.set_axisbelow(True)
    ax.yaxis.set_major_formatter(lambda v, _: f"${v/1000:.0f}k")

    # Category
    ax = fig.add_subplot(gs[0, 2])
    c = df.groupby("pizza_category")["total_price"].sum().sort_values()
    ax.barh(c.index, c.values, color=accent2, height=0.6)
    ax.set_title("Revenue by category", loc="left", fontsize=12, fontweight="bold", pad=10)
    ax.xaxis.set_major_formatter(lambda v, _: f"${v/1000:.0f}k")

    # Hour
    ax = fig.add_subplot(gs[1, :2])
    h = df.groupby("Hour")["order_id"].nunique()
    ax.bar(h.index, h.values, color=accent, width=0.65)
    ax.set_title("Orders by hour of day", loc="left", fontsize=12, fontweight="bold", pad=10)
    ax.set_xticks(list(h.index))

    # Size
    ax = fig.add_subplot(gs[1, 2])
    s = df.groupby("pizza_size")["total_price"].sum().sort_values(ascending=False)
    s = s.rename({"XXL": "XL/XXL", "XL": "XL/XXL"}).groupby(level=0).sum().sort_values(ascending=False)
    wedges, *_ = ax.pie(s.values, autopct="%1.0f%%", startangle=120, pctdistance=0.7,
                        colors=["#ff7a33", "#4cc38a", "#5a9ffb", "#f2c744"],
                        textprops={"color": "#14171c", "fontsize": 10, "fontweight": "bold"},
                        wedgeprops={"edgecolor": "#14171c", "linewidth": 1.5})
    ax.legend(wedges, s.index, loc="center left", bbox_to_anchor=(0.98, 0.5),
              frameon=False, fontsize=9)
    ax.set_title("Revenue by size", loc="left", fontsize=12, fontweight="bold", pad=10)
    ax.grid(False)

    # Day of week
    ax = fig.add_subplot(gs[2, :2])
    d = df.groupby("Day Name")["order_id"].nunique().reindex(DAYS)
    ax.bar([x[:3] for x in DAYS], d.values, color=accent2, width=0.55)
    ax.set_title("Orders by day of week", loc="left", fontsize=12, fontweight="bold", pad=10)

    # Top pizzas
    ax = fig.add_subplot(gs[2, 2])
    t = df.groupby("pizza_name")["total_price"].sum().nlargest(5).sort_values()
    ax.barh(t.index, t.values, color=accent, height=0.6)
    ax.set_title("Top 5 pizzas by revenue", loc="left", fontsize=12, fontweight="bold", pad=10)
    ax.tick_params(axis="y", labelsize=9)
    ax.xaxis.set_major_formatter(lambda v, _: f"${v/1000:.0f}k")

    out = ASSETS / "dashboard_preview.png"
    fig.savefig(out, dpi=110, facecolor=fig.get_facecolor())
    plt.close(fig)
    return out


def main() -> None:
    df = load()
    k = kpis(df)
    k.to_csv(ROOT / "analysis" / "kpi_summary.csv", index=False)
    breakdowns(df).to_csv(ROOT / "analysis" / "breakdowns.csv", index=False)
    print(k.to_string(index=False))
    print("wrote", dashboard(df, k))


if __name__ == "__main__":
    main()
