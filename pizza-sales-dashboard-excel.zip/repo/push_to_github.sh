#!/usr/bin/env bash
# One-shot: create the GitHub repo and push everything in this folder.
#
#   1. Install GitHub CLI once:  https://cli.github.com   then run:  gh auth login
#   2. cd into this folder and run:  bash push_to_github.sh
#
# Change the name/description below if you want something different.

set -e
REPO_NAME="pizza-sales-dashboard-excel"
DESCRIPTION="Excel pizza sales dashboard: pivot tables, slicers and a full-year sales analysis"

git init -b main
git add .
git commit -m "Pizza sales dashboard: Excel workbook, analysis script and insights"
gh repo create "$REPO_NAME" --public --source=. --description "$DESCRIPTION" --push

echo
echo "Done → https://github.com/Prasanna153/$REPO_NAME"
